# Business ERP Pro — GitHub Ready Android Project

This package is prepared for phone-only GitHub Actions APK builds.

### What is included
- Native Kotlin Android shell
- Material 3 UI
- Mobile bottom navigation
- WebView with JavaScript/DOM storage/cookies
- File upload/download and PDF handling
- Camera permission bridge
- GitHub Actions automatic APK build
- Phone setup guide

### Build
Upload the contents of this ZIP to a GitHub repository, then use:
Actions → Build Business ERP APK → Run workflow.

### Important
Replace `ERP_URL` in `MainActivity.kt` with your real HTTPS ERP server URL.
