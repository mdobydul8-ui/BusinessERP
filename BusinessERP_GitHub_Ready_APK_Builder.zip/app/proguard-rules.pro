# Business ERP release rules
