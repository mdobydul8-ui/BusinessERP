package com.businesserp.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.businesserp.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    // Change this to your deployed HTTPS ERP server.
    private val ERP_URL = "https://YOUR-ERP-DOMAIN.example/"

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        fileCallback?.onReceiveValue(uri?.let { arrayOf(it) })
        fileCallback = null
    }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(this, "Camera permission is required for camera upload.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupWebView()
        setupNavigation()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            cameraPermission.launch(Manifest.permission.CAMERA)
        if (savedInstanceState == null) web.loadUrl(ERP_URL)
    }

    private fun setupWebView() {
        web = WebView(this)
        binding.webContainer.addView(web, 0, android.widget.FrameLayout.LayoutParams(-1,-1))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(true)
            builtInZoomControls = false
            displayZoomControls = false
            userAgentString = "$userAgentString BusinessERPAndroid/1.0"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                binding.progress.isVisible = true
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.progress.isVisible = false
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                return if (u.startsWith(ERP_URL) || u.startsWith("https://")) false else {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url)); true
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, uploadMsg: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = uploadMsg
                val accept = params?.acceptTypes?.firstOrNull()?.ifBlank { "*/*" } ?: "*/*"
                filePicker.launch(accept)
                return true
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
                        ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        cameraPermission.launch(Manifest.permission.CAMERA)
                    } else request.grant(request.resources)
                }
            }
        }
        web.setDownloadListener { url, _, _, _, _ ->
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun setupNavigation() {
        binding.bottomNav.setOnItemSelectedListener {
            val js = when (it.itemId) {
                com.businesserp.app.R.id.nav_home -> "if(window.page) page('dashboard');"
                com.businesserp.app.R.id.nav_sales -> "if(window.page) page('invoice');"
                com.businesserp.app.R.id.nav_stock -> "if(window.page) page('items');"
                com.businesserp.app.R.id.nav_reports -> "if(window.page) page('reports');"
                else -> ""
            }
            web.evaluateJavascript("javascript:$js", null)
            true
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}