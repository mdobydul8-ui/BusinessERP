# ফোন থেকে APK বানানোর সহজ গাইড

## 1) GitHub
Chrome দিয়ে https://github.com এ লগইন করুন।
নিজের নামে একটি PRIVATE repository বানান, যেমন:
BusinessERP

## 2) Upload
এই ZIP-এর ভেতরের সব ফাইল repository root-এ upload করুন।
খেয়াল রাখবেন:
build.gradle এবং settings.gradle repository-এর প্রথম স্তরেই থাকবে।

## 3) ERP URL
এই ফাইল খুলুন:
app/src/main/java/com/businesserp/app/MainActivity.kt

এই লাইনটি খুঁজুন:
private val ERP_URL = "https://YOUR-ERP-DOMAIN.example/"

আপনার live ERP HTTPS address বসান।

## 4) Automatic build
GitHub repository:
Actions → Build Business ERP APK → Run workflow

অথবা main/master-এ push করলে workflow নিজে চলবে।

## 5) APK
Build শেষ হলে:
Actions → সর্বশেষ workflow → Artifacts → BusinessERP-debug-apk

ZIP download করে APK বের করুন এবং ফোনে install করুন।

## গুরুত্বপূর্ণ
এই package-এ GitHub account তৈরি করা নেই এবং করা সম্ভবও নয়—আপনাকেই নিজের account-এ repository তৈরি করতে হবে।
এতে আপনার account password/token রাখা হয়নি।

এই package হলো Android app + automatic GitHub APK builder.
পুরো ERP-এর backend/database এখনো আলাদা deployment দরকার। Android app সেই live ERP URL-এ connect করবে।
