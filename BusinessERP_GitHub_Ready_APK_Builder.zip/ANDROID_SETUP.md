# Business ERP Pro — Android Studio Project

This is a native Android shell around the Business ERP Pro web ERP.

## Architecture
- Native Android Kotlin + Material 3 UI
- WebView with JavaScript, DOM storage and cookies
- Mobile bottom navigation connected to ERP pages
- File chooser for PDF/image/document uploads
- Camera permission and WebView camera permission bridge
- External download/PDF handling
- Back-button navigation
- HTTPS-only deployment target
- Same ERP backend/database is shared with desktop browsers

## IMPORTANT: set your server URL
Open:
app/src/main/java/com/businesserp/app/MainActivity.kt

Change:
`private val ERP_URL = "https://YOUR-ERP-DOMAIN.example/"`

to your real HTTPS ERP URL.

Do NOT point a production app at plain HTTP.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Set the ERP_URL.
4. Build > Build APK(s).
5. For a release APK: Build > Generate Signed Bundle / APK > APK.

## Server requirement
The Android app is intentionally not a local WebView-only database. It connects to the central ERP server, so your phone and computer see the same customers, invoices, stock, payments and reports.

For offline mode, add a sync layer (Room/SQLite local cache + authenticated API + conflict handling) rather than storing the business database directly inside the WebView.

## Production security
- HTTPS
- Strong session secret
- Short-lived authenticated sessions
- Server-side role permissions
- Backups
- Audit logging
- Secure password reset
- Rate limiting
- Proper tax/accounting configuration

The native shell is ready; the ERP backend URL is the only deployment-specific value.
